import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers import LlamaTokenizer, LlamaForCausalLM
from accelerate import Accelerator
import torch


def init_model(model_id):
    tokenizer = LlamaTokenizer.from_pretrained('klyang/MentaLLaMA-chat-7B', cache_dir=" ", use_auth_token=" ")
    model = LlamaForCausalLM.from_pretrained('klyang/MentaLLaMA-chat-7B', torch_dtype=torch.float16, cache_dir=" ", device_map="cuda", use_auth_token=" ")

    return tokenizer, model

def process_rows(rows, tokenizer, model, system_message, device):
    tb_predictions = []
    tb_reasonings = []
    pb_predictions = []
    pb_reasonings = []
    
    for _, row in rows.iterrows():
        user_message = {
            "role": "user",
            "content": f"Given the post: '{row['text']}', analyze the content to identify the presence of Thwarted Belongingness and Perceived Burdensomeness. The output should be in the following format:\n\n'Thwarted Belongingness: OUTPUT: 0 (No) or 1 (Yes); REASONING:'\n\n'Perceived Burdensomeness: OUTPUT: 0 (No) or 1 (Yes); REASONING:'"
        }

        messages = [system_message, user_message]
        input_ids = tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            return_tensors="pt"
        ).to(device)

        outputs = model.generate(
            input_ids,
            max_new_tokens=256,
            eos_token_id=tokenizer.eos_token_id,
            do_sample=False,
            temperature=0,
        )
        response = outputs[0][input_ids.shape[-1]:]
        decoded_response = tokenizer.decode(response, skip_special_tokens=True)

        # Extract predictions and reasoning
        tb_prediction = None
        pb_prediction = None
        tb_reasoning = ""
        pb_reasoning = ""

        # Extract Thwarted Belongingness prediction and reasoning
        tb_start = decoded_response.find("Thwarted Belongingness: OUTPUT:")
        if tb_start != -1:
            tb_end = decoded_response.find("Perceived Burdensomeness:", tb_start)
            tb_segment = decoded_response[tb_start:tb_end].strip() if tb_end != -1 else decoded_response[tb_start:].strip()
            if "OUTPUT: 1" in tb_segment:
                tb_prediction = 1
            elif "OUTPUT: 0" in tb_segment:
                tb_prediction = 0
            tb_reason_start = tb_segment.find("REASONING:")
            if tb_reason_start != -1:
                tb_reasoning = tb_segment[tb_reason_start + len("REASONING:"):].strip()
        
        # Improved extraction logic for Perceived Burdensomeness
        pb_start = decoded_response.find("Perceived Burdensomeness: OUTPUT:")
        if pb_start != -1:
            pb_segment = decoded_response[pb_start:].strip()
            if "OUTPUT: 1" in pb_segment:
                pb_prediction = 1
            elif "OUTPUT: 0" in pb_segment:
                pb_prediction = 0
            pb_reason_start = pb_segment.find("REASONING:")
            if pb_reason_start != -1:
                pb_reasoning = pb_segment[pb_reason_start + len("REASONING:"):].strip()

        tb_predictions.append(tb_prediction)
        tb_reasonings.append(tb_reasoning)
        pb_predictions.append(pb_prediction)
        pb_reasonings.append(pb_reasoning)
    
    return tb_predictions, tb_reasonings, pb_predictions, pb_reasonings

def main():
    accelerator = Accelerator()
    device = accelerator.device

    model_id = "klyang/MentaLLaMA-chat-7B"  # replace with your model ID
    df = pd.read_csv("IRF_var.csv")

    system_message = {
        "role": "system",
        "content": "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    }
        
    # Initialize the model and tokenizer
    tokenizer, model = init_model(model_id)
    model = accelerator.prepare(model)

    # Split DataFrame into chunks for parallel processing
    num_gpus = torch.cuda.device_count()
    chunk_size = (len(df) + num_gpus - 1) // num_gpus  # Ensure all rows are included
    chunks = [df.iloc[i*chunk_size:(i+1)*chunk_size] for i in range(num_gpus)]
    
    # Process rows in parallel
    tb_predictions = []
    tb_reasonings = []
    pb_predictions = []
    pb_reasonings = []
    
    for chunk in chunks:
        tb_preds, tb_reas, pb_preds, pb_reas = process_rows(chunk, tokenizer, model, system_message, device)
        tb_predictions.extend(tb_preds)
        tb_reasonings.extend(tb_reas)
        pb_predictions.extend(pb_preds)
        pb_reasonings.extend(pb_reas)
    
    # Ensure the lengths match
    assert len(tb_predictions) == len(df), f"Mismatch: {len(tb_predictions)} Thwarted Belongingness predictions for {len(df)} rows"
    assert len(tb_reasonings) == len(df), f"Mismatch: {len(tb_reasonings)} Thwarted Belongingness reasonings for {len(df)} rows"
    assert len(pb_predictions) == len(df), f"Mismatch: {len(pb_predictions)} Perceived Burdensomeness predictions for {len(df)} rows"
    assert len(pb_reasonings) == len(df), f"Mismatch: {len(pb_reasonings)} Perceived Burdensomeness reasonings for {len(df)} rows"
    
    # Add the predictions and reasoning to the DataFrame
    df['Thwarted_Belongingness_prediction'] = tb_predictions
    df['Thwarted_Belongingness_prediction'] = pd.to_numeric(df['Thwarted_Belongingness_prediction'], errors='coerce').astype('Int64')
    df['Thwarted_Belongingness_reasoning'] = tb_reasonings
    df['Perceived_Burdensomeness_prediction'] = pb_predictions
    df['Perceived_Burdensomeness_prediction'] = pd.to_numeric(df['Perceived_Burdensomeness_prediction'], errors='coerce').astype('Int64')
    df['Perceived_Burdensomeness_reasoning'] = pb_reasonings

    # Save the DataFrame to a new CSV file
    df.to_csv('IRF_var_MentalLlama_7B.csv', index=False)

    print(f"Predictions and reasoning saved to original file")

if __name__ == "__main__":
    main()

    
