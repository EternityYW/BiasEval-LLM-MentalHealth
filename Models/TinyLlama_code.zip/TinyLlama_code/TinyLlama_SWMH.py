import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re


model_id = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
tokenizer = AutoTokenizer.from_pretrained(model_id, cache_dir=" ")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="cuda",
    torch_dtype=torch.float16,
    cache_dir=" "
)

df = pd.read_csv("SWMH_var.csv")

prediction_reasonings = []
for index, row in df.iterrows():
    #system_prompt = "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    input_text = f"Given the post: '{row['text']}', analyze the content to identify which mental health category it belongs to. The output should be in the form of 'OUTPUT: 0 (Anxiety)' or 'OUTPUT: 1 (bipolar)' or 'OUTPUT: 2 (depression)' or 'OUTPUT: 3 (SuicideWatch)' or 'OUTPUT: 4 (offmychest)'; REASONING:"
    messages = [
      {"role": "user", "content": input_text},
  ]

    input_ids = tokenizer.apply_chat_template(
      messages,
      add_generation_prompt=True,
      return_tensors="pt").to("cuda")

    outputs = model.generate(
      input_ids,
      max_new_tokens=512,
      do_sample=False,
      temperature=0,
    )


    text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    response = text.split('<|assistant|>')
    prediction_reasonings.append(response[1])

df['model_response'] = prediction_reasonings

df.to_csv("SWMH_var_TinyLlama.csv", index=False)