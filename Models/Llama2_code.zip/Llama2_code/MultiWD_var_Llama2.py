import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
from accelerate import Accelerator
import torch

def init_model(model_id):
    tokenizer = AutoTokenizer.from_pretrained(model_id, cache_dir=" ")
    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.float16, cache_dir=" ", device_map="cuda")
    return tokenizer, model

def process_rows(rows, tokenizer, model, system_message, device):
    dimensions = ["Spiritual", "Physical", "Intellectual", "Social", "Vocational", "Emotional"]
    predictions = {dimension: [] for dimension in dimensions}
    reasonings = {dimension: [] for dimension in dimensions}
    
    for _, row in rows.iterrows():
        user_message = {
            "role": "user",
            "content": f"Given the post: '{row['text']}', analyze the content to identify relevant wellness dimensions. The output should be in the following format:\n\n'Spiritual: OUTPUT: 0 (No) or 1 (Yes); REASONING:'\n\n'Physical: OUTPUT: 0 (No) or 1 (Yes); REASONING:\n\n'Intellectual: OUTPUT: 0 (No) or 1 (Yes); REASONING:'\n\n'Social: OUTPUT: 0 (No) or 1 (Yes); REASONING:\n\n'Vocational: OUTPUT: 0 (No) or 1 (Yes); REASONING:'\n\n'Emotional: OUTPUT: 0 (No) or 1 (Yes); REASONING:'"
        }

        messages = [system_message, user_message]
        input_ids = tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            return_tensors="pt"
        ).to(device)

        outputs = model.generate(
            input_ids,
            max_new_tokens=1024,
            eos_token_id=tokenizer.eos_token_id,
            do_sample=False,
            temperature=0,
        )
        response = outputs[0][input_ids.shape[-1]:]
        decoded_response = tokenizer.decode(response, skip_special_tokens=True)

        # Extract predictions and reasoning for each dimension
        for dimension in dimensions:
            dim_start = decoded_response.find(f"{dimension}: OUTPUT:")
            if dim_start != -1:
                dim_segment = decoded_response[dim_start:].split("\n", 1)[0].strip()
                if "OUTPUT: 1" in dim_segment:
                    predictions[dimension].append(1)
                elif "OUTPUT: 0" in dim_segment:
                    predictions[dimension].append(0)
                else:
                    predictions[dimension].append(None)
                
                reasoning_start = dim_segment.find("REASONING:")
                if reasoning_start != -1:
                    reasoning = dim_segment[reasoning_start + len("REASONING:"):].strip()
                else:
                    reasoning = ""
                
                reasonings[dimension].append(reasoning)
            else:
                predictions[dimension].append(None)
                reasonings[dimension].append("")

    return predictions, reasonings

def main():
    accelerator = Accelerator()
    device = accelerator.device

    model_id = model = "meta-llama/Llama-2-7b-chat-hf"
    df = pd.read_csv("MultiWD_var.csv")

    system_message = {
        "role": "system",
        "content": "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    }
        
    # Initialize the model and tokenizer
    tokenizer, model = init_model(model_id)
    model = accelerator.prepare(model)

    # Split DataFrame into chunks for parallel processing
    num_gpus = torch.cuda.device_count()
    chunk_size = (len(df) + num_gpus - 1) // num_gpus  # Ensure all rows are included
    chunks = [df.iloc[i*chunk_size:(i+1)*chunk_size] for i in range(num_gpus)]
    
    # Process rows in parallel
    dimensions = ["Spiritual", "Physical", "Intellectual", "Social", "Vocational", "Emotional"]
    all_predictions = {dimension: [] for dimension in dimensions}
    all_reasonings = {dimension: [] for dimension in dimensions}
    
    for chunk in chunks:
        predictions, reasonings = process_rows(chunk, tokenizer, model, system_message, device)
        for dimension in dimensions:
            all_predictions[dimension].extend(predictions[dimension])
            all_reasonings[dimension].extend(reasonings[dimension])
    
    # Ensure the lengths match
    for dimension in dimensions:
        assert len(all_predictions[dimension]) == len(df), f"Mismatch: {len(all_predictions[dimension])} predictions for {len(df)} rows in {dimension}"
        assert len(all_reasonings[dimension]) == len(df), f"Mismatch: {len(all_reasonings[dimension])} reasonings for {len(df)} rows in {dimension}"
    
    # Add the predictions and reasoning to the DataFrame
    for dimension in dimensions:
        df[f'{dimension}_prediction'] = all_predictions[dimension]
        df[f'{dimension}_prediction'] = pd.to_numeric(df[f'{dimension}_prediction'], errors='coerce').astype('Int64')
        df[f'{dimension}_reasoning'] = all_reasonings[dimension]

    # Save the DataFrame to a new CSV file
    df.to_csv('MultiWD_var_Llama2_8B_Inst.csv', index=False)

    print(f"Predictions and reasoning saved to original file")

if __name__ == "__main__":
    main()

    
