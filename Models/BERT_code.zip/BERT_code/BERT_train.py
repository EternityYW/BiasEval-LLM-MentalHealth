import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AdamW
import pandas as pd
import numpy as np
from torch.utils.data import Dataset, DataLoader

#train_data = pd.read_csv("email_depression_training.csv")
#test_data = pd.read_csv("Stanford_email_var.csv")
#train_data = pd.read_csv("dreaddit_training.csv")
#test_data = pd.read_csv("dreaddit_var.csv")
train_data = pd.read_csv("CSSRS_suicide_training.csv")
test_data = pd.read_csv("CSSRS_suicide_var.csv")
#train_data = pd.read_csv("IRF_belong_training.csv")
#test_data = pd.read_csv("IRF_belong_testing.csv")
#train_data = pd.read_csv("IRF_burden_training.csv")
#test_data = pd.read_csv("IRF_burden_testing.csv")
#train_data = pd.read_csv("DepSeverity_training.csv")
#test_data = pd.read_csv("DepSeverity_testing.csv")
#train_data = pd.read_csv("LT_EDI_training.csv")
#test_data = pd.read_csv("LT_EDI_testing.csv")
#train_data = pd.read_csv("CAMS_training.csv")
#test_data = pd.read_csv("CAMS_var.csv")
#train_data = pd.read_csv("SWMH_training.csv")
#test_data = pd.read_csv("SWMH_var.csv")

#tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased", cache_dir=" ")
#model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased", cache_dir=" ", num_labels=5)
#tokenizer = AutoTokenizer.from_pretrained("roberta-base", cache_dir=" ")
#model = AutoModelForSequenceClassification.from_pretrained("roberta-base", cache_dir=" ", num_labels=5)
tokenizer = AutoTokenizer.from_pretrained("mental/mental-bert-base-uncased")
model = AutoModelForSequenceClassification.from_pretrained("mental/mental-bert-base-uncased", num_labels=5)

class EmailDepressionDataset(Dataset):
    def __init__(self, dataframe):
        self.dataframe = dataframe

    def __len__(self):
        return len(self.dataframe)

    def __getitem__(self, idx):
        row = self.dataframe.iloc[idx]
        encoding = tokenizer.encode_plus(
            row['text'],
            max_length=512,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        label = row['label']
        return {
            'input_ids': torch.tensor(encoding['input_ids'].squeeze(0), dtype=torch.long), 
            'attention_mask': torch.tensor(encoding['attention_mask'].squeeze(0), dtype=torch.long), 
            'labels': torch.tensor(label, dtype=torch.long)
        }
    
train_dataset = EmailDepressionDataset(train_data)
test_dataset = EmailDepressionDataset(test_data)

batch_size=16
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# Step 5: Initialize the model and optimizer
lr=5e-6

optimizer = AdamW(model.parameters(), lr=lr)
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model.to(device)
model = torch.nn.DataParallel(model)

# Training loop
NUM_EPOCHS = 5
for epoch in range(NUM_EPOCHS):
    model.train()
    running_loss = 0.0
    for batch in train_loader:
        optimizer.zero_grad()

        inputs = {k: v.to(device) for k, v in batch.items() if k != 'labels'}
        labels = batch['labels'].to(device)
        outputs = model(**inputs, labels=labels)
        loss = outputs.loss.mean()
        
        loss.backward()
        optimizer.step()
        running_loss += loss.item()

    print(f'Epoch {epoch+1}, Loss: {running_loss/len(train_loader)}')

# Evaluation loop
model.eval()
correct_predictions = 0
total_predictions = 0
all_preds = []

for batch in test_loader:
    with torch.no_grad():
        inputs = {k: v.to(device) for k, v in batch.items() if k != 'labels'}
        labels = batch['labels'].to(device)
        outputs = model(**inputs)
        preds = torch.argmax(outputs.logits, dim=1)

        correct_predictions += (preds == labels).sum().item()
        total_predictions += labels.shape[0]

        all_preds.extend(preds.cpu().numpy())

# Concatenate predictions and labels, and calculate accuracy
test_data['predictions'] = all_preds
test_data.to_csv('CSSRS_var_MentalBERT.csv', index=False)
test_accuracy = correct_predictions / total_predictions
print(f'Testing Accuracy: {test_accuracy * 100:.2f}%')
print('Finished Job!')