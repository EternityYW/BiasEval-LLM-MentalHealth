import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoConfig, AdamW
import pandas as pd
import numpy as np
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import accuracy_score

#train_data = pd.read_csv("email_depression_training.csv")
#test_data = pd.read_csv("email_depression_testing.csv")
#train_data = pd.read_csv("dreaddit_training.csv")
#test_data = pd.read_csv("dreaddit_testing.csv")
#train_data = pd.read_csv("CSSRS_suicide_training.csv")
#test_data = pd.read_csv("CSSRS_suicide_testing.csv")
#train_data = pd.read_csv("IRF_belong_training.csv")
#test_data = pd.read_csv("IRF_belong_testing.csv")
train_data = pd.read_csv("IRF_training.csv")
test_data = pd.read_csv("IRF_var.csv")
#train_data = pd.read_csv("DepSeverity_training.csv")
#test_data = pd.read_csv("DepSeverity_testing.csv")
#train_data = pd.read_csv("LT_EDI_training.csv")
#test_data = pd.read_csv("LT_EDI_testing.csv")
#train_data = pd.read_csv("CAMS_training.csv")
#test_data = pd.read_csv("CAMS_testing.csv")
#train_data = pd.read_csv("DepressionEmo_training.csv")
#test_data = pd.read_csv("DepressionEmo_testing.csv")
#train_data = pd.read_csv("MultiWD_training.csv")
#test_data = pd.read_csv("MultiWD_var.csv")
#train_data = pd.read_csv("SAD_training.csv")
#test_data = pd.read_csv("SAD_var.csv")

config = AutoConfig.from_pretrained("roberta-base", cache_dir=" ", num_labels=2)
config.problem_type = "multi_label_classification"  # sets the appropriate output processing

# Load model with modified configuration
#tokenizer = AutoTokenizer.from_pretrained("mental/mental-bert-base-uncased")
#model = AutoModelForSequenceClassification.from_pretrained("mental/mental-bert-base-uncased", config=config)
tokenizer = AutoTokenizer.from_pretrained("roberta-base", cache_dir=" ")
model = AutoModelForSequenceClassification.from_pretrained("roberta-base", cache_dir=" ", config=config)

class EmailDepressionDataset(Dataset):
    def __init__(self, dataframe):
        self.dataframe = dataframe
        # Directly specifying the label column names
        '''
        self.label_columns = [
            'anger', 'brain dysfunction (forget)', 'emptiness',
            'hopelessness', 'loneliness', 'sadness', 'suicide intent',
            'worthlessness'
        ]
        
        self.label_columns = ['Spiritual', 'Physical', 'Intellectual', 'Social', 'Vocational', 'Emotional']
        
        self.label_columns = ['Financial_Problem', 'Other', 'Everyday_Decision_Making', 'Emotional_Turmoil', 'School', 'Family_Issues', 'Social_Relationships', 'Work', 'Health_Fatigue_Physical_Pain']
       
        self.label_columns = ['Thwarted_Belongingness', 'Perceived_Burdensomeness']
        '''
        self.label_columns = ['Thwarted_Belongingness', 'Perceived_Burdensomeness']
        
    def __len__(self):
        return len(self.dataframe)
    
    def __getitem__(self, idx):
        row = self.dataframe.iloc[idx]
        encoding = tokenizer.encode_plus(
            row['text'],
            max_length=512,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        # Collect labels from the specified columns into a single array
        labels = np.array(row[self.label_columns], dtype=np.int64)
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'labels': torch.from_numpy(labels)
        }
    
train_dataset = EmailDepressionDataset(train_data)
test_dataset = EmailDepressionDataset(test_data)

batch_size=32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

lr=1e-5
loss_function = nn.BCEWithLogitsLoss()

optimizer = AdamW(model.parameters(), lr=lr)
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model.to(device)
model = torch.nn.DataParallel(model)

# Training loop
NUM_EPOCHS = 5
model.train()
for epoch in range(NUM_EPOCHS):
    total_loss = 0
    for batch in train_loader:
        optimizer.zero_grad()

        inputs = {k: v.to(device) for k, v in batch.items() if k != 'labels'}
        labels = batch['labels'].to(device).float()
        outputs = model(**inputs)
        logits = outputs.logits
        loss = loss_function(logits, labels)  # Apply the loss function directly
        loss = loss.mean()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    avg_loss = total_loss / len(train_loader)
    print(f'Epoch {epoch+1}, Loss: {avg_loss:.4f}')
    
# Evaluation loop
model.eval()
all_labels = []
all_preds = []

for batch in test_loader:
    with torch.no_grad():
        inputs = {k: v.to(device) for k, v in batch.items() if k != 'labels'}
        labels = batch['labels'].to(device)
        outputs = model(**inputs)
        preds = torch.sigmoid(outputs.logits).cpu().numpy() > 0.5
        preds = preds.astype(int)  
        all_preds.append(preds)
        all_labels.append(labels.cpu().numpy())

# Flatten the predictions and labels
all_preds = np.vstack(all_preds)
all_labels = np.vstack(all_labels)

# Calculate accuracy for each label and overall accuracy
accuracies = [accuracy_score(all_labels[:, i], all_preds[:, i]) for i in range(all_labels.shape[1])]
overall_accuracy = np.mean(accuracies)

test_data['RoBERTa_predictions'] = [str(list(pred)) for pred in all_preds]
test_data.to_csv('IRF_var_RoBERTa.csv', index=False)
print(f'Overall Accuracy: {overall_accuracy * 100:.2f}%')
print('Finished Job!')
