import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re


tokenizer = AutoTokenizer.from_pretrained("google/gemma-7b-it", cache_dir=" ")
model = AutoModelForCausalLM.from_pretrained(
    "google/gemma-7b-it",
    device_map="auto",
    cache_dir=" "
)

df = pd.read_csv("CAMS_var.csv")

prediction_reasonings = []
for index, row in df.iterrows():
    system_prompt = "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    input_text = f"Given the post: '{row['text']}', analyze the content to identify the most possible cause of the user's mental issue. The output should be in the form of 'OUTPUT: 0 (No reason)' or 'OUTPUT: 1 (Bias or abuse)' or 'OUTPUT: 2 (Jobs and Careers)' or 'OUTPUT: 3 (Medication)' or 'OUTPUT: 4 (Relationship)' or 'OUTPUT: 5 (Alienation)'; REASONING:"
    messages = [
       {"role": "user", "content": system_prompt + '\n\n' + input_text},
  ]
    
    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )
    
    inputs = tokenizer.encode(prompt, add_special_tokens=True, return_tensors="pt")

    outputs = model.generate(input_ids=inputs.to(model.device), max_new_tokens=2048)
    

    text = tokenizer.decode(outputs[0])
    
    #text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)

    response = text.split('<start_of_turn>model')
    prediction_reasonings.append(response[1])

df['model_response'] = prediction_reasonings

df.to_csv("CAMS_var_Gemma_7B_Inst.csv", index=False)