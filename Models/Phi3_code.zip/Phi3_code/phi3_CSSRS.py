import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re


model_id = "microsoft/Phi-3-mini-128k-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True, cache_dir=" ")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="cuda",
    trust_remote_code=True,
    torch_dtype=torch.float16,
    cache_dir=" "
)

df = pd.read_csv("CSSRS_suicide_var.csv")

def process_row(row):
    system_prompt = "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    input_text = f"Given the post: '{row['text']}', analyze the content to predict the user's suicide risk. The output should be in the form of 'OUTPUT: 0 (Ideation)' or 'OUTPUT: 1 (Supportive)' or 'OUTPUT: 2 (Indicator)' or 'OUTPUT: 3 (Attempt)' or 'OUTPUT: 4 (Behavior)'; REASONING:"
    messages = [
        {"role": "user", "content": system_prompt + '\n\n' + input_text},
    ]

    input_ids = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        return_tensors="pt"
    ).to("cuda")

    outputs = model.generate(
        input_ids,
        max_new_tokens=512,
        do_sample=False,
        temperature=0,
    )


    text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    
    try:
        # Split the text to find the OUTPUT and REASONING sections
        split_text = text.split("REASONING: OUTPUT:")
        if len(split_text) < 2:
            return "", ""
        
        # Extract the second part after the split which contains the desired OUTPUT and REASONING
        output_section = split_text[1]

        # Extract the prediction from the output_section
        prediction_match = re.search(r'(\d) \(.*?\)', output_section)
        if not prediction_match:
            return "", ""
        
        prediction = prediction_match.group(1).strip()

        # Extract the reasoning part
        reasoning_start = output_section.find("REASONING:") + len("REASONING:")
        reasoning = output_section[reasoning_start:].strip()

        return prediction, reasoning
    except Exception as e:
        return "", ""

predictions = []
reasonings = []

# Iterate over each row in the DataFrame
for index, row in df.iterrows():
    prediction, reasoning = process_row(row)
    if index % 100 == 0:
        print('Progress:', index, 'finished')
    predictions.append(prediction)
    reasonings.append(reasoning)

# Ensure the lengths match
assert len(predictions) == len(df), f"Mismatch: {len(predictions)} predictions for {len(df)} rows"
assert len(reasonings) == len(df), f"Mismatch: {len(reasonings)} reasonings for {len(df)} rows"

# Add the predictions and reasoning to the DataFrame
df['prediction'] = predictions
df['reasoning'] = reasonings

df.to_csv("CSSRS_suicide_var_Phi3.csv", index=False)