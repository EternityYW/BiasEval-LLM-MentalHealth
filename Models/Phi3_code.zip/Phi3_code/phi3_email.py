import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re


model_id = "microsoft/Phi-3-mini-128k-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True, cache_dir=" ")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="cuda",
    trust_remote_code=True,
    torch_dtype=torch.float16,
    cache_dir=" "
)

df = pd.read_csv("Stanford_email_var.csv")

def process_row(row):
    system_prompt = "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    input_text = f"Given the patient email: '{row['text']}', analyze the content to predict whether the patient is likely suffering from depression. The output should be in the form of OUTPUT: 0 (non-depression) or 1 (depression); REASONING:"
    messages = [
        {"role": "user", "content": system_prompt + '\n\n' + input_text},
    ]

    input_ids = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        return_tensors="pt"
    ).to("cuda")

    outputs = model.generate(
        input_ids,
        max_new_tokens=512,
        do_sample=False,
        temperature=0,
    )


    text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    
    prediction, reasoning = "", ""
    
    output_pattern = re.compile(r'OUTPUT: (\d) \(.*?\); REASONING: OUTPUT: (\d) \(.*?\)')
    reasoning_pattern = re.compile(r'REASONING: (.*)', re.DOTALL)

    output_match = output_pattern.search(text)
    reasoning_match = reasoning_pattern.search(text)

    if output_match and reasoning_match:
        prediction = output_match.group(2).strip()
        reasoning = reasoning_match.group(1).strip().split("\n", 1)[1].strip()      
    
    return prediction, reasoning


predictions = []
reasonings = []

# Iterate over each row in the DataFrame
for index, row in df.iterrows():
    prediction, reasoning = process_row(row)
    if index % 100 == 0:
        print('Progress:', index, 'finished')
    predictions.append(prediction)
    reasonings.append(reasoning)

# Ensure the lengths match
assert len(predictions) == len(df), f"Mismatch: {len(predictions)} predictions for {len(df)} rows"
assert len(reasonings) == len(df), f"Mismatch: {len(reasonings)} reasonings for {len(df)} rows"

# Add the predictions and reasoning to the DataFrame
df['prediction'] = predictions
df['reasoning'] = reasonings

df.to_csv("Stanford_email_var_Phi3.csv", index=False)