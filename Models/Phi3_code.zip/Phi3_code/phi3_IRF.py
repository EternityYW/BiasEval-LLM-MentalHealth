import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re


model_id = "microsoft/Phi-3-mini-128k-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True, cache_dir=" ")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="cuda",
    trust_remote_code=True,
    torch_dtype=torch.float16,
    cache_dir=" "
)

df = pd.read_csv("IRF_var.csv")

def extract_prediction_and_reasoning(text, dimension):
    split_text = text.split("Perceived Burdensomeness: 0 (No) or 1 (Yes); REASONING:")
    if len(split_text) < 2:
        return None, None

    # Extract the second part after the split which contains the desired OUTPUT and REASONING
    pattern = re.compile(
        rf"{dimension}: (\d) \(.*?\); REASONING: (.*?)(?:\n|$)",
        re.DOTALL
    )
    match = pattern.search(split_text[1])
    if match:
        prediction = int(match.group(1))
        reasoning = match.group(2).strip()
        return prediction, reasoning
    return None, None

# Initialize empty columns
df['Thwarted_Belongingness_Prediction'] = None
df['Thwarted_Belongingness_Reasoning'] = None
df['Perceived_Burdensomeness_Prediction'] = None
df['Perceived_Burdensomeness_Reasoning'] = None

for index, row in df.iterrows():
    system_prompt = "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    input_text = f"Given the post: '{row['text']}', analyze the content to identify the presence of Thwarted Belongingness and Perceived Burdensomeness. The output should be in the following format:\n\n'Thwarted Belongingness: 0 (No) or 1 (Yes); REASONING:'\n\n'Perceived Burdensomeness: 0 (No) or 1 (Yes); REASONING:'"
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": input_text}
    ]

    input_ids = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        return_tensors="pt",
        truncation=True,
    ).to("cuda")

    outputs = model.generate(
        input_ids,
        max_new_tokens=512,
        do_sample=False,
        temperature=0,
    )

    text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    print(text)

    # Extract predictions and reasonings for both dimensions manually
    thwarted_belongingness_prediction, thwarted_belongingness_reasoning = extract_prediction_and_reasoning(text, "Thwarted Belongingness")
    perceived_burdensomeness_prediction, perceived_burdensomeness_reasoning = extract_prediction_and_reasoning(text, "Perceived Burdensomeness")

    # Save the predictions and reasonings to the dataframe
    df.at[index, 'Thwarted_Belongingness_Prediction'] = thwarted_belongingness_prediction
    df.at[index, 'Thwarted_Belongingness_Reasoning'] = thwarted_belongingness_reasoning
    df.at[index, 'Perceived_Burdensomeness_Prediction'] = perceived_burdensomeness_prediction
    df.at[index, 'Perceived_Burdensomeness_Reasoning'] = perceived_burdensomeness_reasoning


df.to_csv("IRF_var_Phi3.csv", index=False)