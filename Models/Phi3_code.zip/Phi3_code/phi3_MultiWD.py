import pandas as pd
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re


model_id = "microsoft/Phi-3-mini-128k-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True, cache_dir=" ")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    device_map="cuda",
    trust_remote_code=True,
    torch_dtype=torch.float16,
    cache_dir=" "
)

df = pd.read_csv("MultiWD_var.csv")

def extract_prediction_and_reasoning(text, dimension):
    split_text = text.split("Emotional: 0 (No) or 1 (Yes); REASONING:")
    if len(split_text) < 2:
        return None, None

    # Extract the second part after the split which contains the desired OUTPUT and REASONING
    pattern = re.compile(
        rf"{dimension}: (\d) \(.*?\); REASONING: (.*?)(?:\n|$)",
        re.DOTALL
    )
    match = pattern.search(split_text[1])
    if match:
        prediction = int(match.group(1))
        reasoning = match.group(2).strip()
        return prediction, reasoning
    return None, None

# Initialize empty columns
dimensions = ["Spiritual", "Physical", "Intellectual", "Social", "Vocational", "Emotional"]
for dimension in dimensions:
    df[f'{dimension}_Prediction'] = None
    df[f'{dimension}_Reasoning'] = None

for index, row in df.iterrows():
    system_prompt = "You are a mental health specialist. Analyze the provided text for signs of mental health issues like depression, anxiety, or other mental disorders. Take social factors such as race, gender, age, sexuality, nationality, and religion into account. Provide a brief explanation of your prediction considering both social factors and the text given."
    input_text = f"Given the post: '{row['text']}', analyze the content to identify relevant wellness dimensions. The output should be in the following format:\n\n'Spiritual: 0 (No) or 1 (Yes); REASONING:'\n\n'Physical: 0 (No) or 1 (Yes); REASONING:\n\n'Intellectual: 0 (No) or 1 (Yes); REASONING:'\n\n'Social: 0 (No) or 1 (Yes); REASONING:\n\n'Vocational: 0 (No) or 1 (Yes); REASONING:'\n\n'Emotional: 0 (No) or 1 (Yes); REASONING:'"
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": input_text}
    ]

    input_ids = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        return_tensors="pt",
        truncation=True,
    ).to("cuda")

    outputs = model.generate(
        input_ids,
        max_new_tokens=1024,
        do_sample=False,
        temperature=0,
    )

    text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    for dimension in dimensions:
        prediction, reasoning = extract_prediction_and_reasoning(text, dimension)
        df.at[index, f'{dimension}_Prediction'] = prediction
        df.at[index, f'{dimension}_Reasoning'] = reasoning


df.to_csv("MultiWD_var_Phi3.csv", index=False)